package br.com.zup.desafioproposta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesafioPropostaApplicationTests {

	@Test
	void contextLoads() {
	}

}
